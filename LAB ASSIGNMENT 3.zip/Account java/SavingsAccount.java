public class SavingsAccount extends Account {
    protected double interestRate;
    protected double minimumBalance;

    // Parameterized constructor
    public SavingsAccount(String accountNumber, double balance, double interestRate, double minimumBalance) {
        super(accountNumber, balance); // call base class constructor
        this.interestRate = interestRate;
        this.minimumBalance = minimumBalance;
    }

    // Functional method 1: calculate interest
    public double calculateInterest() {
        return balance * (interestRate / 100);
    }

    // Functional method 2: check minimum balance
    public boolean isAboveMinimum() {
        return balance >= minimumBalance;
    }

    // Override display
    @Override
    public void display() {
        super.display(); // call base class display
        System.out.println("Interest Rate: " + interestRate + "%");
        System.out.println("Minimum Balance: " + minimumBalance);
        System.out.println("Interest Value: " + calculateInterest());
        System.out.println("Above Minimum Balance? " + isAboveMinimum());
    }

    @Override
    public String toString() {
        return "SavingsAccount[" + super.toString() + ", interestRate=" + interestRate + ", minimumBalance=" + minimumBalance + "]";
    }
}