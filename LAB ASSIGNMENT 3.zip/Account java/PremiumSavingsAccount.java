public class PremiumSavingsAccount extends SavingsAccount {
    protected int rewardPoints;
    protected int freeTransactions;

    // Parameterized constructor
    public PremiumSavingsAccount(String accountNumber, double balance, double interestRate, double minimumBalance,
                                 int rewardPoints, int freeTransactions) {
        super(accountNumber, balance, interestRate, minimumBalance); // call intermediate class constructor
        this.rewardPoints = rewardPoints;
        this.freeTransactions = freeTransactions;
    }

    // Functional method 1: calculate reward value
    public double calculateRewardValue() {
        return rewardPoints * 10; // example: each point = $10
    }

    // Functional method 2: check if free transactions left
    public boolean hasFreeTransactions() {
        return freeTransactions > 0;
    }

    // Override display
    @Override
    public void display() {
        super.display(); // call intermediate class display
        System.out.println("Reward Points: " + rewardPoints);
        System.out.println("Free Transactions: " + freeTransactions);
        System.out.println("Reward Value: " + calculateRewardValue());
        System.out.println("Has Free Transactions? " + hasFreeTransactions());
    }

    @Override
    public String toString() {
        return "PremiumSavingsAccount[" + super.toString() + ", rewardPoints=" + rewardPoints + ", freeTransactions=" + freeTransactions + "]";
    }
}