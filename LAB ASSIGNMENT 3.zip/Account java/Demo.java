public class Demo {
    public static void main(String[] args) {
        System.out.println("=== Base Class: Account ===");
        Account acc = new Account("A001", 5000);
        acc.display();
        acc.deposit(1000);
        acc.withdraw(2000);
        System.out.println(acc.toString());

        System.out.println("\n=== Intermediate Class: SavingsAccount ===");
        SavingsAccount sav = new SavingsAccount("S001", 8000, 5.0, 1000);
        sav.display();
        sav.deposit(2000);
        sav.withdraw(500);
        System.out.println(sav.toString());

        System.out.println("\n=== Derived Class: PremiumSavingsAccount ===");
        PremiumSavingsAccount prem = new PremiumSavingsAccount("P001", 15000, 6.0, 2000, 100, 5);
        prem.display();
        prem.deposit(5000);
        prem.withdraw(3000);
        System.out.println(prem.toString());
    }
}