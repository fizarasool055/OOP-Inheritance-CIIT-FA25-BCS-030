public class Account {
    protected String accountNumber;
    protected double balance;

    // Parameterized constructor
    public Account(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    // Functional method 1: deposit
    public void deposit(double amount) {
        balance += amount;
        System.out.println(amount + " deposited. Balance: " + balance);
    }

    // Functional method 2: withdraw
    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println(amount + " withdrawn. Balance: " + balance);
        } else {
            System.out.println("Insufficient balance!");
        }
    }

    // Display method
    public void display() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
    }

    @Override
    public String toString() {
        return "Account[accountNumber=" + accountNumber + ", balance=" + balance + "]";
    }
}